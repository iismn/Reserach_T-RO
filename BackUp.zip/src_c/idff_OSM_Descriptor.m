Recall_ = [];
for Recall_N = [1 5 10 20 30 40 50 60 70 80]
    Matched_Idx = 0;
    for i = 1:size(pcl_descriptor,1)

        L1=sum(abs(osm_descriptor-pcl_descriptor(i,:)),2);
        [~, idxMin] = mink(L1,Recall_N);
        idxMin
        [result_x, result_y] = deg2utm(osm_pos(idxMin,2),osm_pos(idxMin,1));
        result_pos = [result_x, result_y]; 
        gt_pos = pcl_pos(i,:);
        
        dist_pos = sqrt(sum((result_pos - gt_pos).^2,2));
        
        if sum(dist_pos<25)>0
            Matched_Idx = Matched_Idx+1;
        end
    end
    
    Recall_N_Result = Matched_Idx/size(pcl_descriptor,1);
    Recall_ = [Recall_; Recall_N_Result];
    Recall_N_Result
    Recall_N
end