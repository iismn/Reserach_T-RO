% IRiS DUNSAN / HANBIT / JEONMIN / KAIST E / N / W / MUNJI / YUSEONG / IRAP URBAN 08 / 14 / 15 / 27
% clc; clear;
% DB_NUM = [488 316 337 396 257 460 267 163 257 877 424 895];
% 
% DB_Frq = DB_NUM / sum(DB_NUM);
% 
% DB_Train = round(sum(DB_NUM)*0.6);
% DB_Val = round(sum(DB_NUM)*0.2);
% DB_Test = round(sum(DB_NUM)*0.2);
% 
% DB_Frq_Train = floor(DB_Frq * DB_Train);
% DB_Frq_Val = floor(DB_Frq * DB_Val);
% DB_Frq_Test = floor(DB_Frq * DB_Test);

%% DB GEN
clc; clear; 
DB.List_2D = dir('**/2D');
DB.List_3D = dir('**/3D');
DB.List_UTM_2D = dir('**/POS_2D');
DB.List_UTM_3D = dir('**/POS_3D');

FList_2D  ={};
FList_3D  ={};
FList_UTM_2D = [];
FList_UTM_3D = [];

for i = 1:size(DB.List_2D,1)
   
    if DB.List_2D(i).bytes == 0
        continue
    end
    % 2D
    F_Name = DB.List_2D(i).name;
    F_Path = DB.List_2D(i).folder;
    
    F_Path_Split = split(F_Path,'/');
    
    Full_Path = strcat(F_Path_Split(end-2),'/',F_Path_Split(end-1),'/',F_Path_Split(end),'/',F_Name);
    FList_2D{end+1} = Full_Path{1};

%     Full_Path = strcat(F_Path,'/',F_Name);
%     FList_2D{end+1} = Full_Path;
%     
%     TEMP_IMG = imread(Full_Path);
%     if sum(size(TEMP_IMG) == [700 700 3]) ~= 3
%         TEMP_IMG = imresize(TEMP_IMG, [710 710]);
%         r = centerCropWindow2d(size(TEMP_IMG),[700 700]);
%         TEMP_IMG = imcrop(TEMP_IMG,r);
%         imwrite(TEMP_IMG,Full_Path)
%     end
        
    
    % UTM 2D
    F_Name = DB.List_UTM_2D(i).name;
    F_Path = DB.List_UTM_2D(i).folder;
    Full_Path = strcat(F_Path,'/',F_Name);
    
    LOCAL_Coordinate_IO = textscan(fopen(Full_Path),'%f64 %f64');
    FList_UTM_2D = [FList_UTM_2D cell2mat(LOCAL_Coordinate_IO)'];
    
    fclose all;

end

for i = 1:size(DB.List_3D,1)
   
    if DB.List_3D(i).bytes == 0
        continue
    end
    
    % 3D
    F_Name = DB.List_3D(i).name;
    F_Path = DB.List_3D(i).folder;
    
    F_Path_Split = split(F_Path,'/');
    
    Full_Path = strcat(F_Path_Split(end-2),'/',F_Path_Split(end-1),'/',F_Path_Split(end),'/',F_Name);
    FList_3D{end+1} = Full_Path{1};
   
%     Full_Path = strcat(F_Path,'/',F_Name);
%     FList_3D{end+1} = Full_Path;
% 
%     TEMP_IMG = imread(Full_Path);
%     if sum(size(TEMP_IMG) == [700 700 3]) ~= 3
%         TEMP_IMG = imresize(TEMP_IMG, [710 710]);
%         r = centerCropWindow2d(size(TEMP_IMG),[700 700]);
%         TEMP_IMG = imcrop(TEMP_IMG,r);
%         imwrite(TEMP_IMG,Full_Path)
%     end
    
    % UTM 3D
    F_Name = DB.List_UTM_3D(i).name;
    F_Path = DB.List_UTM_3D(i).folder;
    Full_Path = strcat(F_Path,'/',F_Name);
    
    LOCAL_Coordinate_IO = textscan(fopen(Full_Path),'%f64 %f64');
    FList_UTM_3D = [FList_UTM_3D cell2mat(LOCAL_Coordinate_IO)'];
    
    
    fclose all;

end

FList_2D = FList_2D';
FList_3D = FList_3D';


%%
% Val
FList_3D_Val  ={};
FList_UTM_Val_3D = [];
for i = 1:round(size(FList_3D,1)/1.4)
    
    iter = round(i*1.4+2);
    
    if iter >= size(FList_3D,1)
        return
    end
    
%     FList_2D_Val{end+1} = FList_2D{iter};
    FList_3D_Val{end+1} = FList_3D{iter};
%     FList_UTM_Val_2D = [FList_UTM_Val_2D FList_UTM_2D(:,iter)];
    FList_UTM_Val_3D = [FList_UTM_Val_3D FList_UTM_3D(:,iter)];
%     FList_2D{iter} = nan;
%     FList_3D{iter} = nan;
%     FList_UTM(:,iter) = [nan nan]';
    
end
%%
% FList_2D_Val = FList_2D_Val';
FList_3D_Val = FList_3D_Val';

%%
% Test
FList_2D_Test  ={};
FList_3D_Test ={};
FList_UTM_Test = [];

for i = 1:round(size(FList_2D,1)/5)
    
    iter = i*5+4;
    
    if iter >= size(FList_2D,1)
        return
    end
    
    FList_2D_Test{end+1} = FList_2D{iter};
    FList_3D_Test{end+1} = FList_3D{iter};
    FList_UTM_Test = [FList_UTM_Test FList_UTM(:,iter)];
    
    FList_2D{iter} = nan;
    FList_3D{iter} = nan;
    FList_UTM(:,iter) = [nan nan]';
    
end
%%
FList_2D_Test = FList_2D_Test';
FList_3D_Test = FList_3D_Test';



%%
% Train
FList_2D_Train  ={};
FList_3D_Train  ={};
FList_UTM_Train = [];

for i = 1:size(FList_2D,1)
    
    if isnan(FList_2D{i})
        continue
    end
    
    FList_2D_Train{end+1} = FList_2D{i};
    FList_3D_Train{end+1} = FList_3D{i};
    FList_UTM_Train = [FList_UTM_Train FList_UTM(:,i)];

end

FList_2D_Train = FList_2D_Train';
FList_3D_Train = FList_3D_Train';


%% dbStruct Save - Train
dbStruct.whichSet = 'train';
dbStruct.dbImageFns = FList_2D_Train;
dbStruct.utmDb = FList_UTM_Train;
dbStruct.qImageFns = FList_3D_Train_q;
dbStruct.utmQ = FList_UTM_Train_q;
dbStruct.numImages = size(dbStruct.dbImageFns,1);
dbStruct.numQueries = size(dbStruct.qImageFns,1);
dbStruct.posDistThr = 25;
dbStruct.posDistSqThr=625;
dbStruct.nonTrivPosDistSqThr = 800;

save('OSM_5K_Train.mat','dbStruct');

%% dbStruct Save - Val
dbStruct.whichSet = 'val';
dbStruct.dbImageFns = FList_2D_Val;
dbStruct.utmDb = FList_UTM_Val_2D;
dbStruct.qImageFns = FList_3D_Val_q;n val set, query count: 294
dbStruct.utmQ = FList_UTM_Val_q;
dbStruct.numImages = size(dbStruct.dbImageFns,1);
dbStruct.numQueries = size(dbStruct.qImageFns,1);
dbStruct.posDistThr = 25;
dbStruct.posDistSqThr = 625;
dbStruct.nonTrivPosDistSqThr = 800;

save('OSM_5K_Val.mat','dbStruct');

%% dbStruct Save - Test
dbStruct.whichSet = 'test';
dbStruct.dbImageFns = FList_2D;
dbStruct.utmDb = FList_UTM_2D;
dbStruct.qImageFns = FList_3D_Val;
dbStruct.utmQ = FList_UTM_Val_3D;
dbStruct.numImages = size(dbStruct.dbImageFns,1);
dbStruct.numQueries = size(dbStruct.qImageFns,1);
dbStruct.posDistThr = 10;
dbStruct.posDistSqThr = 100;
dbStruct.nonTrivPosDistSqThr = 400;

save('OSM_5K_Test.mat','dbStruct');

%%
% Val
% FList_2D_Val  ={};
FList_3D_Train_q ={};
FList_UTM_Train_q = [];

for i = 1:round(size(FList_2D_Train,1)/1.4)
    
    iter = round(i*1.4+2);
    
    if isnan(FList_3D_Train{i})
        continue
    end
    
%     FList_2D_Val{end+1} = FList_2D{iter};
    FList_3D_Train_q{end+1} = FList_3D_Train{iter};
    FList_UTM_Train_q = [FList_UTM_Train_q FList_UTM_Train(:,iter)];
    
end
%%
% FList_2D_Val = FList_2D_Val';
FList_3D_Train_q = FList_3D_Train_q';


%%

FList_3D_Val_q ={};
FList_UTM_Val_q = [];
for i = 1:round(size(FList_2D_Val,1)/2)
    
    iter = i*2+2;
%     
%     if iter >= size(FList_UTM_Val,1)
%         return
%     end
    
%     FList_2D_Val{end+1} = FList_2D{iter};
    FList_3D_Val_q{end+1} = FList_3D_Val{iter};
    FList_UTM_Val_q = [FList_UTM_Val_q FList_UTM_Val_2D(:,iter)];
    
end
%%
% FList_2D_Val = FList_2D_Val';
FList_3D_Val_q = FList_3D_Val_q';   


%% dbStruct Save - Train
dbStruct.whichSet = 'train';
dbStruct.dbImageFns = FList_2D_Train;
dbStruct.utmDb = FList_UTM_Train;
dbStruct.qImageFns = FList_3D_Train_q;
dbStruct.utmQ = FList_UTM_Train_q;
dbStruct.numImages = size(dbStruct.dbImageFns,1);
dbStruct.numQueries = size(dbStruct.qImageFns,1);
dbStruct.posDistThr = 10;
dbStruct.posDistSqThr=100;
dbStruct.nonTrivPosDistSqThr = 400;

save('OSM_5K_Train.mat','dbStruct');

%% dbStruct Save - Val
dbStruct.whichSet = 'val';
dbStruct.dbImageFns = FList_2D_Val;
dbStruct.utmDb = FList_UTM_Val_2D;
dbStruct.qImageFns = FList_3D_Val_q;
dbStruct.utmQ = FList_UTM_Val_q;
dbStruct.numImages = size(dbStruct.dbImageFns,1);
dbStruct.numQueries = size(dbStruct.qImageFns,1);
dbStruct.posDistThr = 25;
dbStruct.posDistSqThr = 625;
dbStruct.nonTrivPosDistSqThr = 800;

save('OSM_5K_Val.mat','dbStruct');

%% dbStruct Save - Test
dbStruct.whichSet = 'test';
dbStruct.dbImageFns = FList_2D;
dbStruct.utmDb = FList_UTM;
dbStruct.qImageFns = FList_3D_Val;
dbStruct.utmQ = FList_UTM_Val_2D;
dbStruct.numImages = size(dbStruct.dbImageFns,1);
dbStruct.numQueries = size(dbStruct.qImageFns,1);
dbStruct.posDistThr = 25;
dbStruct.posDistSqThr = 625;
dbStruct.nonTrivPosDistSqThr = 1000;

save('OSM_5K_Test.mat','dbStruct');
