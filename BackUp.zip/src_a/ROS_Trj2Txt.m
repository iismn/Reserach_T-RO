clc; clear;
Flist = dir('GT');

for T = 1:size(Flist,1)-2

    F_Name = Flist(T+2).name
    DB = importdata(F_Name);
    Timestamp = [];
    X = [];
    Y = [];
    Z = [];
    qx = [];
    qy = [];
    qz = [];
    qw = [];

    for iT = 1: size(DB.Poses,1)
        Timestamp(end+1) = DB.Poses(iT).Header.Stamp.seconds;
        X(end+1) = DB.Poses(iT).Pose.Position.X;
        Y(end+1) = DB.Poses(iT).Pose.Position.Y;
        Z(end+1) = DB.Poses(iT).Pose.Position.Z;
        qx(end+1) = DB.Poses(iT).Pose.Orientation.X;
        qy(end+1) = DB.Poses(iT).Pose.Orientation.Y;
        qz(end+1) = DB.Poses(iT).Pose.Orientation.Z;
        qw(end+1) = DB.Poses(iT).Pose.Orientation.W;

    end

    Total_Path = [Timestamp; X; Y; Z; qx; qy; qz; qw;]';
%     Total_Path = [Timestamp; -X; Z; Y; qx; qy; qz; qw;]';        % FOR LeGO-LOAM

    F_id = fopen(strcat(F_Name,'.txt'),'w');
    fprintf(F_id, '%f %f %f %f %f %f %f %f\n', Total_Path.')

    fclose(F_id);
    
    
    
end

%%

Timestamp = [];
X = [];
Y = [];
Z = [];
qx = [];
qy = [];
qz = [];
qw = [];

for iT = 1: size(DB.Poses,1)
    Timestamp(end+1) = DB.Poses(iT).Header.Stamp.seconds;
    X(end+1) = DB.Poses(iT).Pose.Position.X;
    Y(end+1) = DB.Poses(iT).Pose.Position.Y;
    Z(end+1) = DB.Poses(iT).Pose.Position.Z;
    qx(end+1) = DB.Poses(iT).Pose.Orientation.X;
    qy(end+1) = DB.Poses(iT).Pose.Orientation.Y;
    qz(end+1) = DB.Poses(iT).Pose.Orientation.Z;
    qw(end+1) = DB.Poses(iT).Pose.Orientation.W;

end

Total_Path = [Timestamp; X; Y; Z; qx; qy; qz; qw;]';
%     Total_Path = [Timestamp; -X; Z; Y; qx; qy; qz; qw;]';        % FOR LeGO-LOAM

% F_id = fopen(strcat('GT_UTM_KAIST','.txt'),'w');
% fprintf(F_id, '%f %f %f %f %f %f %f %f\n', Total_Path.')
% 
% fclose(F_id);
  
%%
Timestamp = [];
X = [];
Y = [];
Z = [];
qx = [];
qy = [];
qz = [];
qw = [];

for iT = 1: size(DB2.Poses,1)
    Timestamp(end+1) = DB2.Poses(iT).Header.Stamp.seconds;
    X(end+1) = DB2.Poses(iT).Pose.Position.X;
    Y(end+1) = DB2.Poses(iT).Pose.Position.Y;
    Z(end+1) = DB2.Poses(iT).Pose.Position.Z;
    qx(end+1) = DB2.Poses(iT).Pose.Orientation.X;
    qy(end+1) = DB2.Poses(iT).Pose.Orientation.Y;
    qz(end+1) = DB2.Poses(iT).Pose.Orientation.Z;
    qw(end+1) = DB2.Poses(iT).Pose.Orientation.W;

end

Total_PathDL = [Timestamp; X; Y; Z; qx; qy; qz; qw;]';

    
%%
TCP1 = rossubscriber('/RETRIEVAL_MODULE/DL/Path/GTUTM')
TCP2 = rossubscriber('/RETRIEVAL_MODULE/DL/Path/DLUTM')
% TCP3 = rossubscriber('/ublox/ins/fused_path')
TCP4 = rossubscriber('/RETRIEVAL_MODULE/GLOBAL/mapping/path')
STP5 = rossubscriber('/RETRIEVAL_MODULE/LOCAL/MAP/Init')
%%
DB = TCP1.LatestMessage
DB2= TCP2.LatestMessage
% DB3 = TCP3.LatestMessage
DB4 = TCP4.LatestMessage
TP = STP5.LatestMessage
%%
SEJONG_INIT_UTM = [UTMx UTMy];
Timestamp = [];
X = [];
Y = [];
Z = [];
qx = [];
qy = [];
qz = [];
qw = [];
Total_Path = [];
for iT = 1: size(DB.Poses,1)
    Timestamp(end+1) = DB.Poses(iT).Header.Stamp.seconds;
    X(end+1) = DB.Poses(iT).Pose.Position.X;
    Y(end+1) = DB.Poses(iT).Pose.Position.Y;
    Z(end+1) = 0;
    qx(end+1) = DB.Poses(iT).Pose.Orientation.X;
    qy(end+1) = DB.Poses(iT).Pose.Orientation.Y;
    qz(end+1) = DB.Poses(iT).Pose.Orientation.Z;
    qw(end+1) = DB.Poses(iT).Pose.Orientation.W;

end

Total_Path = [Timestamp; X; Y; Z; qx; qy; qz; qw;]';

Timestamp = [];
X = [];
Y = [];
Z = [];
qx = [];
qy = [];
qz = [];
qw = [];
Total_Path2 = [];
for iT = 1: size(DB2.Poses,1)
    Timestamp(end+1) = DB2.Poses(iT).Header.Stamp.seconds;
    X(end+1) = DB2.Poses(iT).Pose.Position.X;
    Y(end+1) = DB2.Poses(iT).Pose.Position.Y;
    Z(end+1) = 0;
    qx(end+1) = DB2.Poses(iT).Pose.Orientation.X;
    qy(end+1) = DB2.Poses(iT).Pose.Orientation.Y;
    qz(end+1) = DB2.Poses(iT).Pose.Orientation.Z;
    qw(end+1) = DB2.Poses(iT).Pose.Orientation.W;

end

Total_Path2 = [Timestamp; X; Y; Z; qx; qy; qz; qw;]';
Total_Path3= [];
Timestamp = [];
X = [];
Y = [];
Z = [];
qx = [];
qy = [];
qz = [];
qw = [];

for iT = 1: size(DB4.Poses,1)
    Timestamp(end+1) = DB4.Poses(iT).Header.Stamp.seconds;
    X(end+1) = DB4.Poses(iT).Pose.Position.X;
    Y(end+1) = DB4.Poses(iT).Pose.Position.Y;
    Z(end+1) = 0;
    qx(end+1) = DB4.Poses(iT).Pose.Orientation.X;
    qy(end+1) = DB4.Poses(iT).Pose.Orientation.Y;
    qz(end+1) = DB4.Poses(iT).Pose.Orientation.Z;
    qw(end+1) = DB4.Poses(iT).Pose.Orientation.W;

end

Total_Path3 = [Timestamp; X; Y; Z; qx; qy; qz; qw;]'

%%

for j = 1:size(Total_Path3,1)
    if Total_Path3(j,1) < Total_Path2(1,1)+0.1 && Total_Path3(j,1) > Total_Path2(1,1)-0.1
        idx = j
    end
end

Total_Path3 = Total_Path3(idx:end,:)
Total_Path3(:,2) = Total_Path3(:,2) - Total_Path3(1,2)+Total_Path2(1,2);
Total_Path3(:,3) = Total_Path3(:,3) - Total_Path3(1,3)+Total_Path2(1,3);
    
%%
figure(1)
clf
plot(Total_Path(:,2), Total_Path(:,3), 'o-', 'LineWidth',3)
hold on; axis equal; grid on
plot(Total_Path2(:,2), Total_Path2(:,3), '*-', 'LineWidth',3)
hold on; axis equal; grid on
plot(Total_Path3(:,2), Total_Path3(:,3), '-', 'LineWidth',3)

%%
F_id = fopen(strcat('DL_UTM_KAIST','.txt'),'w');
fprintf(F_id, '%f %f %f %f %f %f %f %f\n', Total_Path3.');
fclose(F_id);
  













