%% LIO_SAM Path Sub
% LIO_SAM_Path = rossubscriber('/lio_sam/mapping/path')
LeGO_LOAM_Path = rossubscriber('/mapping/path')
% GT_Path = rossubscriber('/RETRIEVAL_MODULE/GLOBAL/mapping/path')

%% Path Sub LIO-SAM
LIO_SAM_KAIST_NORTH = LIO_SAM_Path.LatestMessage


%% Path Sub LeGO-LOAM
LeGO_LOAM_KAIST_NORTH = LeGO_LOAM_Path.LatestMessage


%% Path Sub Proposed Method
GT_KAIST_NORTH = GT_Path.LatestMessage

