FList_UTM = FList_UTM';

all_dist = 0;

for i = 1:size(FList_UTM,1)-1
    dist = norm(FList_UTM(i,:)-FList_UTM(i+1,:));
    all_dist = all_dist + dist;
end

fprintf('Travel Distance : %2.3f Km\n', all_dist/1000)