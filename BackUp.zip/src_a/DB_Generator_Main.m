%% Deep Learning / DB GENERATOR
% iismn@kaist.ac.kr
% KAIST IRiS Lab.
% Autonomouse Vehicle Team
%
% DB Generator with PCD + LocalMap Point DataBase
% DB for Siamese OSM-NetVLAD DeepLearning Network
% Research : Autonomous Driving without High-Definition Detailed Prior-Map
%
% Copyright 2021.9.15

clc; clear; 
DATA_Path = '/home/iismn/WorkSpace/SUB_DB/DB_DL_V2/DB_RAW/POS_PCL/IRiS/KAIST_EAST/';
addpath(genpath(DATA_Path))

SAVE_Path_2D = '/home/iismn/WorkSpace/SUB_DB/DB_DL_V2/DB/IRiS/KAIST_EAST/2D/';
SAVE_Path_3D = '/home/iismn/WorkSpace/SUB_DB/DB_DL_V2/DB/IRiS/KAIST_EAST/3D/';
SAVE_Path_POS = '/home/iismn/WorkSpace/SUB_DB/DB_DL_V2/DB/IRiS/KAIST_EAST/POS/';

%% B. ROS BAG to START POINT
% BAG.DATA = rosbag('HANBIT.bag');
% BAG.DATA = select(BAG.DATA,'Topic','/ublox/fix');
% BAG.FIXMSG = readMessages(BAG.DATA,'DataFormat','struct');
% [LOCAL_Coordinate.StartPoint.UTM_X, LOCAL_Coordinate.StartPoint.UTM_Y, ~] = deg2utm(BAG.FIXMSG{1}.Latitude, BAG.FIXMSG{1}.Longitude);

COORD = [36.3711851 127.3607731];
Lat = COORD(1)
Long =  COORD(2)
[LOCAL_Coordinate.StartPoint.UTM_X, LOCAL_Coordinate.StartPoint.UTM_Y, ~] = deg2utm(Lat, Long);
%% C. 2D NGII IMG CONVERTER
% C1. Plot 2D Digital Map 

rawB = fread(fopen('KAIST_NGII_BUILD.geojson'),inf);
rawB = char(rawB');
geojsonValue_BUILD = jsondecode(rawB);

rawR = fread(fopen('KAIST_NGII_ROAD.geojson'),inf);
rawR = char(rawR');
geojsonValue_ROAD = jsondecode(rawR);
%%
%----------------------------------------------------------
DISTMAP = 100;
%----------------------------------------------------------
while true
    PCD_BUILDING_Listing = dir(strcat(DATA_Path,'/BUILD'));
    PCD_ROAD_Listing = dir(strcat(DATA_Path,'/ROAD'));
    POS_Listing = dir(strcat(DATA_Path,'/POS'));
    Iteration = size(POS_Listing,1)-2;
    
    if Iteration >= 5
        for i = 1:Iteration
    
            %% A. DATA LOADER
            % A1. Load PCL / Coordinate TXT 
            PCD_BUILD_Str = PCD_BUILDING_Listing(i+2).name;
            PCD_ROAD_Str = PCD_ROAD_Listing(i+2).name;
            POS_Str = POS_Listing(i+2).name;
            DAT_Str = strsplit(POS_Str,'.');

            LOCAL_PointCloud_BUILD = pcread(strcat(DATA_Path,'/BUILD/',PCD_BUILD_Str));
            LOCAL_PointCloud_ROAD = pcread(strcat(DATA_Path,'/ROAD/',PCD_ROAD_Str));

            delete(strcat(DATA_Path,'/BUILD/',PCD_BUILD_Str));
            delete(strcat(DATA_Path,'/ROAD/',PCD_ROAD_Str));
            
            LOCAL_Coordinate_IO = textscan(fopen(strcat(DATA_Path,'/POS/',POS_Str)),'%s %s %f32 %s %s %f32');
            LOCAL_Coordinate.X_FT = cell2mat(LOCAL_Coordinate_IO(3));
            LOCAL_Coordinate.Y_FT = cell2mat(LOCAL_Coordinate_IO(6));
            
            delete(strcat(DATA_Path,'/POS/',POS_Str));
            
            
            % A3. Convert Local UTM to Global UTM WGS 84
            LOCAL_Coordinate.LocalPoint.UTM_X_FT = LOCAL_Coordinate.X_FT + LOCAL_Coordinate.StartPoint.UTM_X;
            LOCAL_Coordinate.LocalPoint.UTM_Y_FT = LOCAL_Coordinate.Y_FT + LOCAL_Coordinate.StartPoint.UTM_Y;

            % A4. Convert PointCloud Map UTM to Global UTM WGS 84

            LOCAL_Coordinate.TF.MatrixSE3 = [1 0 0 0; 0 1 0 0; 0 0 1 0; LOCAL_Coordinate.StartPoint.UTM_X LOCAL_Coordinate.StartPoint.UTM_Y 0 1];
            LOCAL_Coordinate.TF.MatlabSE3 = affine3d(LOCAL_Coordinate.TF.MatrixSE3);
            LOCAL_PointCloud_BUILD = pctransform(LOCAL_PointCloud_BUILD,LOCAL_Coordinate.TF.MatlabSE3);
            LOCAL_PointCloud_ROAD = pctransform(LOCAL_PointCloud_ROAD,LOCAL_Coordinate.TF.MatlabSE3);

            %% B. 3D PCL IMG CONVERTER
            % B1. Road Segmentation - Initial Filter with Plane Fit
            DB_PointCloud.ROAD = LOCAL_PointCloud_ROAD;

            % B2. Road Segmentation - Filter Road Detail
            FILTER.RoadSeg.Road_Indices = find(DB_PointCloud.ROAD.Intensity < mean(DB_PointCloud.ROAD.Intensity));
            DB_PointCloud.ROAD = select(DB_PointCloud.ROAD, FILTER.RoadSeg.Road_Indices);
        %     DB_PointCloud.ROAD = pcdenoise(DB_PointCloud.ROAD, 'NumNeighbors', 30, 'Threshold', 0.01);

            % B3. Build Segmenation - Initial Road Filter
            DB_PointCloud.BUILD = LOCAL_PointCloud_BUILD;
            FILTER.BuildSeg.Build_Indices = find(DB_PointCloud.BUILD.Intensity > 20);
            DB_PointCloud.BUILD = select(DB_PointCloud.BUILD,FILTER.BuildSeg.Build_Indices);

        %     DB_PointCloud.BUILD = pcdenoise(DB_PointCloud.BUILD,'NumNeighbors',25,'Threshold',0.05);

            
            PARAM.MIN_X_FT = LOCAL_Coordinate.LocalPoint.UTM_X_FT - DISTMAP;
            PARAM.MAX_X_FT = LOCAL_Coordinate.LocalPoint.UTM_X_FT + DISTMAP;
            PARAM.MIN_Y_FT = LOCAL_Coordinate.LocalPoint.UTM_Y_FT - DISTMAP;
            PARAM.MAX_Y_FT = LOCAL_Coordinate.LocalPoint.UTM_Y_FT + DISTMAP;

            LOCAL_Map.maxLength.X = PARAM.MAX_X_FT;
            LOCAL_Map.minLength.X = PARAM.MIN_X_FT;
            LOCAL_Map.maxLength.Y = PARAM.MAX_Y_FT;
            LOCAL_Map.minLength.Y = PARAM.MIN_Y_FT;

            % B5. PLOT PCL IMAGE

            F1 = figure(1);
            pcshow(DB_PointCloud.ROAD)
            hold on
            pcshow(DB_PointCloud.BUILD)
            hold on
            caxis([0 255]); colormap('hsv'); 
            xlim([ LOCAL_Map.minLength.X LOCAL_Map.maxLength.X ]);
            ylim([ LOCAL_Map.minLength.Y LOCAL_Map.maxLength.Y ]);
            view([0 0 1])
            set(gca,'XColor', 'none','YColor','none')
            % B6. SAVE IMAGE
            f = gcf;
            exportgraphics(f,strcat(SAVE_Path_3D,DAT_Str{1},'.png'),'Resolution',200);

            close(F1);

            %%
            F2 = figure(2);
            ngii_Plot(geojsonValue_BUILD, 'BUILDING',LOCAL_Map)
            hold on
            ngii_Plot(geojsonValue_ROAD, 'ROAD',LOCAL_Map)
            hold on

            set(gca,'Color','k')
            set(gcf,'color','k')
            set(gca,'XColor', 'none','YColor','none')

            xlim(F2.CurrentAxes,[ LOCAL_Map.minLength.X LOCAL_Map.maxLength.X ]);
            ylim(F2.CurrentAxes,[ LOCAL_Map.minLength.Y LOCAL_Map.maxLength.Y ]);
            exportgraphics(F2,strcat(SAVE_Path_2D,DAT_Str{1},'.png'),'Resolution',200);


            close(F2);
            
            fileID = fopen(strcat(SAVE_Path_POS,DAT_Str{1},'.txt'),'w');
            fprintf(fileID,'%f64 %f64',[LOCAL_Coordinate.LocalPoint.UTM_X_FT LOCAL_Coordinate.LocalPoint.UTM_Y_FT]);
            fclose(fileID);
            
            
        end
        
    end
    
end




