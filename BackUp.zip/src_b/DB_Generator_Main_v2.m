%% Deep Learning / DB GENERATOR
% iismn@kaist.ac.kr
% KAIST IRiS Lab.
% Autonomouse Vehicle Team
%
% DB Generator with PCD + LocalMap Point DataBase
% DB for Siamese OSM-NetVLAD DeepLearning Network
% Research : Autonomous Driving without High-Definition Detailed Prior-Map
%
% Copyright 2021.9.15

clc; clear; 
SAVE_Path_2D = '/home/iismn/WorkSpace/SUB_DB/DB_DL_v3/IRIS/SEJONG/2D/';
DATA_Path = '/home/iismn/WorkSpace/SUB_DB/DB_DL_v3/IRIS/SEJONG';
%% C. 2D NGII IMG CONVERTER
% C1. Plot 2D Digital Map 

rawB = fread(fopen('SEJONG_NGII_BUILD.geojson'),inf);
rawB = char(rawB');
geojsonValue_BUILD = jsondecode(rawB);

rawR = fread(fopen('SEJONG_NGII_ROAD.geojson'),inf);
rawR = char(rawR');
geojsonValue_ROAD = jsondecode(rawR);
%%
%----------------------------------------------------------
DISTMAP = 80;
%----------------------------------------------------------
while true
    POS_Listing = dir(strcat(DATA_Path,'/POS_3D'));
    Iteration = size(POS_Listing,1)-2;
    
    if Iteration >= 5
        for i = 1:Iteration
    
            %% A. DATA LOADER
            % A1. Load PCL / Coordinate TXT 
            POS_Str = POS_Listing(i+2).name;
            DAT_Str = strsplit(POS_Str,'.');

            LOCAL_Coordinate_IO = textscan(fopen(strcat(DATA_Path,'/POS_3D/',POS_Str)),'%s %s %f32 %s %s %f32');
            LOCAL_Coordinate.X_FT = cell2mat(LOCAL_Coordinate_IO{1});
            LOCAL_Coordinate.Y_FT = cell2mat(LOCAL_Coordinate_IO{2});
            
            LOCAL_Coordinate.X_FT = str2double(LOCAL_Coordinate.X_FT);
            LOCAL_Coordinate.Y_FT = str2double(LOCAL_Coordinate.Y_FT);
            
            % A3. Convert Local UTM to Global UTM WGS 84
            LOCAL_Coordinate.LocalPoint.UTM_X_FT = LOCAL_Coordinate.X_FT;
            LOCAL_Coordinate.LocalPoint.UTM_Y_FT = LOCAL_Coordinate.Y_FT;


            PARAM.MIN_X_FT = LOCAL_Coordinate.LocalPoint.UTM_X_FT - DISTMAP;
            PARAM.MAX_X_FT = LOCAL_Coordinate.LocalPoint.UTM_X_FT + DISTMAP;
            PARAM.MIN_Y_FT = LOCAL_Coordinate.LocalPoint.UTM_Y_FT - DISTMAP;
            PARAM.MAX_Y_FT = LOCAL_Coordinate.LocalPoint.UTM_Y_FT + DISTMAP;

            LOCAL_Map.maxLength.X = PARAM.MAX_X_FT;
            LOCAL_Map.minLength.X = PARAM.MIN_X_FT;
            LOCAL_Map.maxLength.Y = PARAM.MAX_Y_FT;
            LOCAL_Map.minLength.Y = PARAM.MIN_Y_FT;

            %%
            F2 = figure(2);
            clf;
            DB_SubSystem_2DPlot(geojsonValue_BUILD, 'BUILDING',LOCAL_Map)
            hold on
            DB_SubSystem_2DPlot(geojsonValue_ROAD, 'ROAD',LOCAL_Map)
            hold on

            set(gca,'Color','k')
            set(gcf,'color','k')
            set(gca,'XColor', 'none','YColor','none')

            xlim(F2.CurrentAxes,[ LOCAL_Map.minLength.X LOCAL_Map.maxLength.X ]);
            ylim(F2.CurrentAxes,[ LOCAL_Map.minLength.Y LOCAL_Map.maxLength.Y ]);
            exportgraphics(F2,strcat(SAVE_Path_2D,DAT_Str{1},'.png'),'Resolution',200);

            close(F2)   
            fclose all
        end
        
    end
    
end




