rosinit('192.168.50.3')


%%
Curr_Local_Pos = rossubscriber('/RETRIEVAL_MODULE/LOCAL/MAP/Pos')
% Curr_UTM_Pos = rossubscriber('/RETRIEVAL_MODULE/LOCAL/MAP/Pos')
Init_UTM_Pos = rossubscriber('/ublox/fix/init')

%%
clc
Curr_Pos = Curr_Local_Pos.LatestMessage;
Init_UTM = Init_UTM_Pos.LatestMessage;

Curr_Pos_X = Curr_Pos.Pose.Pose.Position.X;
Curr_Pos_Y = Curr_Pos.Pose.Pose.Position.Y;

Init_UTM_X = Init_UTM.Pose.Pose.Position.X;
Init_UTM_Y = Init_UTM.Pose.Pose.Position.Y;

Curr_Pos_ = [Curr_Pos_X Curr_Pos_Y] 
Init_UTM_ = [Init_UTM_X Init_UTM_Y] 
%%
clc



% UTM_GT - Init_UTM_
% Curr_Pos_
UTM_GT =  [ 355648.18032207 4027204.60700064]

UTM_GT - Init_UTM_ - Curr_Pos_
norm(UTM_GT - Init_UTM_ - Curr_Pos_)













