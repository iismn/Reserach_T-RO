%% Deep Learning / DB GENERATOR
% iismn@kaist.ac.kr
% KAIST IRiS Lab.
% Autonomouse Vehicle Team
%
% DB Generator with PCD + LocalMap Point DataBase
% DB for Siamese OSM-NetVLAD DeepLearning Network
% Research : Autonomous Driving without High-Definition Detailed Prior-Map
%
% Copyright 2021.9.15
% clc; clear;
map = pcread('GlobalMap.pcd');
trajectory = pcread('trajectory.pcd');

% Start Point
UTMX = 455940.46530196967;
UTMY = 5425882.150484313;
UTM_TF = rigid3d(eye(3),[UTMX, UTMY, 0]);

% map = pctransform(map,UTM_TF);
% trajectory = pctransform(trajectory,UTM_TF);

%%
% clc; clear; 
SAVE_Path_2D = '/home/iismn/WorkSpace/Research/ComplexUrban_10/DeepLearningDB/2D/';
SAVE_Path_3D = '/home/iismn/WorkSpace/Research/ComplexUrban_10/DeepLearningDB/3D/';
SAVE_Path_POS = '/home/iismn/WorkSpace/Research/ComplexUrban_10/DeepLearningDB/POS/';

%% B. ROS BAG to START POINT
COORD = [48.9842726178 8.39780886782];
Lat = COORD(1);
Long =  COORD(2);
[LOCAL_Coordinate.StartPoint.UTM_X, LOCAL_Coordinate.StartPoint.UTM_Y, ~] = deg2utm(Lat, Long);
%% C. 2D NGII IMG CONVERTER
% C1. Plot 2D Digital Map 

rawB = fread(fopen('kitti08_buildings.geojson'),inf);
rawB = char(rawB');
geojsonValue_BUILD = jsondecode(rawB);

rawR = fread(fopen('kitti08_roads_v2.geojson'),inf);
rawR = char(rawR');
geojsonValue_ROAD = jsondecode(rawR);
%% Image Saving
%----------------------------------------------------------
DISTMAP = 80;
%----------------------------------------------------------
res = 3000;
blankimage = ones(res,res,3);
blankimage(:,:,:) = 0;
Output.Img = blankimage;
Output.Size = 80;

Iteration = size(LOCAL_Coordinate.StartPoint.UTM_X,1);

if Iteration >= 5
    for i = 1:Iteration
        Fname = sprintf('%08d',i);
        %% A. DATA LOADER
        % A1. Load PCL / Coordinate TXT 
%         LOCAL_Coordinate.X_FT = double(trajectory.Location(i,1));
%         LOCAL_Coordinate.Y_FT = double(trajectory.Location(i,2));

        % A3. Convert Local UTM to Global UTM WGS 84
%         LOCAL_Coordinate.LocalPoint.UTM_X_FT = LOCAL_Coordinate.X_FT + LOCAL_Coordinate.StartPoint.UTM_X;
%         LOCAL_Coordinate.LocalPoint.UTM_Y_FT = LOCAL_Coordinate.Y_FT + LOCAL_Coordinate.StartPoint.UTM_Y;
        LOCAL_Coordinate.LocalPoint.UTM_X_FT = LOCAL_Coordinate.StartPoint.UTM_X(i);
        LOCAL_Coordinate.LocalPoint.UTM_Y_FT = LOCAL_Coordinate.StartPoint.UTM_Y(i);

        %% B. 3D PCL IMG CONVERTER
        % B1. Road Segmentation - Initial Filter with Plane Fit

        PARAM.MIN_X_FT = LOCAL_Coordinate.LocalPoint.UTM_X_FT - DISTMAP;
        PARAM.MAX_X_FT = LOCAL_Coordinate.LocalPoint.UTM_X_FT + DISTMAP;
        PARAM.MIN_Y_FT = LOCAL_Coordinate.LocalPoint.UTM_Y_FT - DISTMAP;
        PARAM.MAX_Y_FT = LOCAL_Coordinate.LocalPoint.UTM_Y_FT + DISTMAP;

        LOCAL_Map.maxLength.X = PARAM.MAX_X_FT;
        LOCAL_Map.minLength.X = PARAM.MIN_X_FT;
        LOCAL_Map.maxLength.Y = PARAM.MAX_Y_FT;
        LOCAL_Map.minLength.Y = PARAM.MIN_Y_FT;

        %%
%         blankimage(:,:,:) = 0;
%         Output.Img = blankimage;
%         Output.Size = 80;
%         [~,~,Output]=ngii_Plot_OSM_v2(geojsonValue_BUILD, 'BUILDING',LOCAL_Map,Output);
%         [~,~,Output]=ngii_Plot_OSM_v2(geojsonValue_ROAD, 'ROAD',LOCAL_Map,Output);
%         
%         imwrite(Output.Img,strcat(SAVE_Path_2D,Fname,'.png'))
            i
            fileID = fopen(strcat(SAVE_Path_POS,Fname,'.txt'),'w');
            fprintf(fileID,'%f64 %f64',[LOCAL_Coordinate.LocalPoint.UTM_X_FT LOCAL_Coordinate.LocalPoint.UTM_Y_FT]);
            fclose(fileID);


    end

end

%% PCL Saving
%----------------------------------------------------------
%%
res = 700;
blankimage = ones(res,res,3);
map_FULL = [double(map.Location) double(map.Color)];
map_Size = 100;
tic
parfor (i = 1: size(trajectory.Location,1))
    Fname = sprintf('%08d',i);
    X = trajectory.Location(i,1);
    Y = trajectory.Location(i,2);
    [row, ~, ~] = find(map_FULL(:,1) < X+map_Size & map_FULL(:,1) > X-map_Size & map_FULL(:,2) < Y+map_Size & map_FULL(:,2) > Y-map_Size);
    temp = map_FULL(row,:);
    build_R=find(ismember(temp(:,4:6),[255 200 0],'row'));
    build_u = round((temp(build_R,1)-X+map_Size)*res/(map_Size*2));
    build_v = round((temp(build_R,2)-Y+map_Size)*res/(map_Size*2));

    %%
    road_R=find(ismember(temp(:,4:6),[255 0 255],'row'));
    road_u = round((temp(road_R,1)-X+map_Size)*res/(map_Size*2));
    road_v = round((temp(road_R,2)-Y+map_Size)*res/(map_Size*2));
    
    %%
    blankimage = zeros(res,res,3);
    blankimage = insertShape(blankimage, 'Circle', [build_u res-build_v ones(size(build_u,1),1)*0.05],'LineWidth',1, 'Color', 'yellow');
    blankimage = insertShape(blankimage, 'Circle', [road_u res-road_v ones(size(road_u,1),1)*0.05],'LineWidth',1, 'Color', 'red');
    blankimage = imresize(blankimage,[700 700]);
%     imshow(blankimage)
    
    imwrite(blankimage,strcat(SAVE_Path_3D,Fname,'.png'))
end
toc




    




